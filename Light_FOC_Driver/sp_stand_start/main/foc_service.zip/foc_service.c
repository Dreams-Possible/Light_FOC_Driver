#include"foc_service.h"

//FOC控制数据
typedef struct foc_service_data_t
{
    float real_angle;
    float target_angle;
}foc_service_data_t;
static foc_service_data_t foc_service_data={0};


//FOC服务初始化
void foc_service_init();
//读取当前实际角度
static float read_angle();
//设置PWM
static float set_pwm(u8 ch,float duty);
//产生SVPWM控制信号
static void set_svpwm(float power,float angle);
//PID控制角度
static void foc_service(void*p);
//FOC设置目标角度
void foc_service_set(float angle);


//FOC服务初始化
void foc_service_init()
{
    //创建FOC服务
    xTaskCreate(foc_service,"foc_service",1024*4,NULL,8,NULL);
}

//读取当前实际角度
static float read_angle()
{
    return as5600_read();
}

//设置PWM
static float set_pwm(u8 ch,float duty)
{
    te_pwm_set(ch,duty);
    return 0;
}

//产生SVPWM控制信号
static void set_svpwm(float power,float angle)
{
    // angle*=7;
    //限位
    if(power>1)
    {
        power=1;
    }else
    if(power<0)
    {
        power=0;
    }
    if(angle>360)
    {
        angle=360;
    }else
    if(angle<0)
    {
        angle=0;
    }
    //α-β坐标系下的信号
    float alpha=power*cos(angle);
    float beta=power*sin(angle);
    //Clarke变换为三相电压
    float a=alpha;
    float b=-0.5*alpha+0.866*beta;
    float c=-0.5*alpha-0.866*beta;
    //不失真归一化
    float offset=(fmax(a,fmax(b,c))+fmin(a,fmin(b,c)))/2;
    a=a-offset+0.5;
    b=b-offset+0.5;
    c=c-offset+0.5;
    //设置PWM
    set_pwm(1,a);
    set_pwm(2,b);
    set_pwm(3,c);
}

//PID控制角度
static void foc_service(void*p)
{
    //PID参数
    float k_p=1;
    while(1)
    {
        //读取当前实际角度
        foc_service_data.real_angle=read_angle();
        SP_LOG("ang=%f",foc_service_data.real_angle);
        //计算误差
        float e=k_p*(foc_service_data.target_angle-foc_service_data.real_angle);
        SP_LOG("e=%f",e);
        //调整转矩
        set_svpwm(e,foc_service_data.real_angle);
        //周期执行
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

//FOC设置目标角度
void foc_service_set(float angle)
{
    foc_service_data.target_angle=angle;
}
