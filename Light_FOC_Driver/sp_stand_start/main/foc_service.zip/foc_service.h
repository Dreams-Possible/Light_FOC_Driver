#pragma once

//头文件
#include"sp_sys.h"
#include<math.h>
#include"as5600_driver.h"
#include"te_pwm.h"
#include"main.h"

//FOC服务初始化
void foc_service_init();
//FOC设置目标角度
void foc_service_set(float angle);
